<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
 
use Illuminate\Support\Facades\Schedule;

/*use Illuminate\Support\Facades\Schedule;

|--------------------------------------------------------------------------
| Console Routes
|--------------------------------------------------------------------------
|
| هنا نعرف أوامر Artisan وجدولتها.
|
*/

// أمر تجريبي 