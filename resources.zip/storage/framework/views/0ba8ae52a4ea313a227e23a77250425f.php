

<?php $__env->startSection('content'); ?>
<?php echo e(Breadcrumbs::render('properties.edit', $property)); ?>

    <?php if(session('success')): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 2000)" x-show="show" x-transition
            class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">نجاح!</strong>
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 5000)" x-show="show" x-transition
            class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">خطأ!</strong>
            <ul class="mt-2 list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="max-w-2xl mx-auto mt-10">
        <div class="bg-white shadow-md rounded-2xl p-6 mt-10">
            <h2 class="text-2xl font-bold mb-6 text-center text-gray-700">تعديل بيانات العقار</h2>

            <form action="<?php echo e(route('properties.update', $property->property_id)); ?>" method="POST" class="space-y-4 mt-10">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- اسم العقار -->
                <div>
                    <label for="name" class="block text-gray-700 font-medium mb-1">اسم العقار</label>
                    <input type="text" name="name" id="name"
                        class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value="<?php echo e(old('name', $property->name)); ?>" required>
                </div>

                <!-- العنوان -->
                <div>
                    <label for="address" class="block text-gray-700 font-medium mb-1">العنوان</label>
                    <input type="text" name="address" id="address"
                        class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value="<?php echo e(old('address', $property->address)); ?>" required>
                </div>

                <!-- النوع -->
                <div>
                    <label for="type" class="block text-gray-700 font-medium mb-1">نوع العقار</label>
                    <select name="type" id="type"
                        class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required>
                        <option value="">اختر النوع</option>
                        <option value="big_house" <?php echo e(old('type', $property->type) == 'big_house' ? 'selected' : ''); ?>>بيت كبير</option>
                        <option value="building" <?php echo e(old('type', $property->type) == 'building' ? 'selected' : ''); ?>>عمارة</option>
                        <option value="villa" <?php echo e(old('type', $property->type) == 'villa' ? 'selected' : ''); ?>>فلة</option>
                    </select>
                </div>

                <!-- الحالة -->
                <div>
                    <label for="status" class="block text-gray-700 font-medium mb-1">الحالة</label>
                    <select name="status" id="status"
                        class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required>
                        <option value="">اختر الحالة</option>
                        <option value="available" <?php echo e(old('status', $property->status) == 'available' ? 'selected' : ''); ?>>متاح</option>
                        <option value="rented" <?php echo e(old('status', $property->status) == 'rented' ? 'selected' : ''); ?>>مؤجر</option>
                        <option value="under_maintenance" <?php echo e(old('status', $property->status) == 'under_maintenance' ? 'selected' : ''); ?>>تحت الصيانة</option>
                    </select>
                </div>

                <!-- زر الحفظ -->
                <div class="text-center pt-4">
                    <button type="submit"
                        class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-xl transition duration-300">
                        تحديث العقار
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/properties/edit.blade.php ENDPATH**/ ?>