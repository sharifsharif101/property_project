

 
<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="max-w-5xl mx-auto mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-xl shadow-sm">
        ✅ <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="max-w-5xl mx-auto mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-xl shadow-sm">
        ❌ <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div class="max-w-5xl mx-auto mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-xl shadow-sm">
        <ul class="list-disc list-inside  space-y-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>🔴 <?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="max-w-5xl	 mx-auto py-12 px-6 bg-white shadow-md rounded-3xl">
    <h2 class="text-2xl font-bold text-center text-gray-800 mb-10">تعديل العقد</h2>

    <form action="<?php echo e(route('contracts.update', $contract)); ?>" method="POST" class="space-y-6" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div>
            <label class="block mb-2 font-medium text-gray-700">المستأجر</label>
            <input type="text" value="<?php echo e($contract->tenant->first_name); ?> <?php echo e($contract->tenant->last_name); ?>" readonly
                   class="w-full p-3 border border-gray-200 bg-gray-100 rounded-xl text-gray-700">
            <input type="hidden" name="tenant_id" value="<?php echo e($contract->tenant_id); ?>">
        </div>

        
        <div>
            <label class="block mb-2 font-medium text-gray-700">العقار</label>
            <input type="text" value="<?php echo e($contract->property->name); ?>" readonly
                   class="w-full p-3 border border-gray-200 bg-gray-100 rounded-xl text-gray-700">
            <input type="hidden" name="property_id" value="<?php echo e($contract->property_id); ?>">
        </div>

        
        <div>
            <label class="block mb-2 font-medium text-gray-700">الوحدة</label>
            <input type="text" value="<?php echo e($contract->unit->unit_number); ?>" readonly
                   class="w-full p-3 border border-gray-200 bg-gray-100 rounded-xl text-gray-700">
            <input type="hidden" name="unit_id" value="<?php echo e($contract->unit_id); ?>">
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label for="start_date" class="block mb-2 font-medium text-gray-700">تاريخ البداية</label>
                <input type="date" id="start_date" name="start_date"
                       value="<?php echo e($contract->start_date ? Carbon::parse($contract->start_date)->format('Y-m-d') : ''); ?>"
                       class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none">
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="end_date" class="block mb-2 font-medium text-gray-700">تاريخ النهاية</label>
                <input type="date" id="end_date" name="end_date"
                       value="<?php echo e($contract->end_date ? Carbon::parse($contract->end_date)->format('Y-m-d') : ''); ?>"
                       class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none">
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div>
            <label for="status" class="block mb-2 font-medium text-gray-700">الحالة</label>
            <select name="status" id="status" class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none">
                <?php
                    $statuses = [
                        'active' => 'نشط',
                        'terminated' => 'منتهي',
                        'cancelled' => 'ملغي',
                        'draft' => 'مسودة',
                    ];
                ?>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e($contract->status == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="reference_number" class="block mb-2 font-medium text-gray-700">رقم المرجع</label>
            <input type="text" name="reference_number" id="reference_number"
                   value="<?php echo e($contract->reference_number); ?>"
                   class="w-full p-3 border border-gray-300 rounded-xl bg-gray-100" readonly>
        </div>


<div>
    <label class="block mb-1 font-medium text-gray-700">تحديث ملف العقد (PDF)</label>

    <?php if($contractFile ?? false): ?>
        <p class="mb-2">
            العقد الحالي:
    <a href="<?php echo e(route('contract_files.download', $contract->id)); ?>" target="_blank" class="text-blue-600 underline">
    <?php echo e($contractFile->original_file_name); ?>

</a>
        </p>
    <?php endif; ?>

    <input type="file" name="contract_file" accept="application/pdf"
           class="w-full border p-2 rounded file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
    <?php $__errorArgs = ['contract_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


        
        <div>
            <label for="rent_amount" class="block mb-2 font-medium text-gray-700">قيمة الإيجار</label>
            <input type="number" name="rent_amount" id="rent_amount"
                   value="<?php echo e($contract->rent_amount); ?>"
                   class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none"
                   step="0.01" min="0.01">
            <?php $__errorArgs = ['rent_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="rent_type" class="block mb-2 font-medium text-gray-700">نوع الإيجار</label>
            <select name="rent_type" id="rent_type" class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none">
                <?php
                    $rentTypes = ['daily' => 'يومي', 'weekly' => 'أسبوعي', 'monthly' => 'شهري', 'yearly' => 'سنوي'];
                ?>
                <?php $__currentLoopData = $rentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e($contract->rent_type == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['rent_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="security_deposit" class="block mb-2 font-medium text-gray-700">التأمين</label>
            <input type="number" name="security_deposit" id="security_deposit"
                   value="<?php echo e($contract->security_deposit ?? ''); ?>"
                   class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none"
                   step="0.01" min="0">
            <?php $__errorArgs = ['security_deposit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="termination_reason" class="block mb-2 font-medium text-gray-700">سبب الإنهاء</label>
            <select name="termination_reason" id="termination_reason" class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none">
                <option value="" <?php echo e(is_null($contract->termination_reason) ? 'selected' : ''); ?>>لا يوجد</option>
                <?php
                    $terminationReasons = [
                        'late_payment' => 'التأخر في الدفع',
                        'property_damage' => 'إتلاف العقار',
                        'tenant_request' => 'طلب المستأجر',
                        'landlord_request' => 'طلب المالك',
                        'contract_expiry' => 'انتهاء العقد',
                        'other' => 'أخرى',
                    ];
                ?>
                <?php $__currentLoopData = $terminationReasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e($contract->termination_reason == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div>
            <label for="termination_notes" class="block mb-2 font-medium text-gray-700">ملاحظات الإنهاء</label>
            <textarea id="termination_notes" name="termination_notes"
                      class="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none"
                      rows="4"><?php echo e($contract->termination_notes ?? ''); ?></textarea>
            <?php $__errorArgs = ['termination_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="flex justify-center gap-4 pt-6">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700 transition duration-200 shadow-md">
                حفظ التغييرات
            </button>
            <a href="<?php echo e(route('contracts.index')); ?>" class="bg-gray-500 text-white px-6 py-2 rounded-xl hover:bg-gray-600 transition duration-200 shadow-md">
                رجوع
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/contracts/edit.blade.php ENDPATH**/ ?>