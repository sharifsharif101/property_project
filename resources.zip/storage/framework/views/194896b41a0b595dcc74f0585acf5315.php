

<?php $__env->startSection('title', 'إضافة دفعة جديدة'); ?>

<?php $__env->startSection('content'); ?>

    
    <?php if(session('success')): ?>
        <div class="mb-6 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded-md shadow-sm" role="alert">
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="mb-6 p-4 bg-red-100 border-l-4 border-red-500 text-red-700 rounded-md shadow-sm" role="alert">
            <p><?php echo e(session('error')); ?></p>
        </div>
    <?php endif; ?>

    <!-- البطاقة الرئيسية -->
    <div class="bg-white rounded-xl shadow-lg">
        <!-- رأس البطاقة -->
        <div class="p-6 border-b border-slate-200 flex justify-between items-center">
            <h2 class="text-xl font-bold text-slate-800">تسجيل دفعة إيجار جديدة</h2>
            
            <a href="<?php echo e(url()->previous()); ?>" 
               class="inline-flex items-center gap-2 bg-slate-200 text-slate-700 font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-slate-300 transition-colors">
                <span>العودة</span>
            </a>
        </div>

        <!-- جسم البطاقة (يحتوي على الفورم) -->
        <div class="p-6 md:p-8">
            <form action="<?php echo e(route('payments.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- حقل القسط المستحق -->
                <div>
                    <label for="rent_installment_id" class="block text-sm font-medium text-slate-700 mb-2">القسط المستحق <span class="text-red-500">*</span></label>
                    <select name="rent_installment_id" id="rent_installment_id" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php $__errorArgs = ['rent_installment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">-- اختر القسط --</option>
                        <?php $__currentLoopData = $unpaidInstallments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($installment->id); ?>" <?php echo e(old('rent_installment_id', $selectedInstallmentId ?? '') == $installment->id ? 'selected' : ''); ?>>
                                <?php echo e($installment->contract->tenant->first_name ?? 'N/A'); ?> <?php echo e($installment->contract->tenant->last_name ?? ''); ?> | تاريخ: <?php echo e($installment->due_date); ?> | المتبقي: <?php echo e(number_format($installment->amount_due + $installment->late_fee - $installment->amount_paid, 2)); ?> ريال
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['rent_installment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- حقل المبلغ المدفوع -->
                <div>
                    <label for="amount" class="block text-sm font-medium text-slate-700 mb-2">المبلغ المدفوع <span class="text-red-500">*</span></label>
                    <input type="number" step="0.01" name="amount" id="amount" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount')); ?>" required>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <!-- حقل تاريخ الدفع -->
                <div>
                    <label for="payment_date" class="block text-sm font-medium text-slate-700 mb-2">تاريخ الدفع <span class="text-red-500">*</span></label>
                    <input type="date" name="payment_date" id="payment_date" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" required>
                    <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- حقل طريقة الدفع -->
                <div>
                    <label for="payment_method" class="block text-sm font-medium text-slate-700 mb-2">طريقة الدفع <span class="text-red-500">*</span></label>
                    <select name="payment_method" id="payment_method" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="Cash" <?php echo e(old('payment_method') == 'Cash' ? 'selected' : ''); ?>>نقد (كاش)</option>
                        <option value="Bank Transfer" <?php echo e(old('payment_method') == 'Bank Transfer' ? 'selected' : ''); ?>>حوالة بنكية</option>
                        <option value="Credit Card" <?php echo e(old('payment_method') == 'Credit Card' ? 'selected' : ''); ?>>بطاقة ائتمان</option>
                        <option value="Online Payment" <?php echo e(old('payment_method') == 'Online Payment' ? 'selected' : ''); ?>>دفع إلكتروني</option>
                        <option value="Check" <?php echo e(old('payment_method') == 'Check' ? 'selected' : ''); ?>>شيك</option>
                    </select>
                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <!-- حقل الرقم المرجعي -->
                <div>
                    <label for="transaction_reference" class="block text-sm font-medium text-slate-700 mb-2">الرقم المرجعي (اختياري)</label>
                    <input type="text" name="transaction_reference" id="transaction_reference" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" value="<?php echo e(old('transaction_reference')); ?>">
                </div>
                
                <!-- حقل الملاحظات -->
                <div>
                    <label for="notes" class="block text-sm font-medium text-slate-700 mb-2">ملاحظات (اختياري)</label>
                    <textarea name="notes" id="notes" rows="3" class="block w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"><?php echo e(old('notes')); ?></textarea>
                </div>

                <!-- زر الإرسال -->
                <div class="pt-4 border-t border-slate-200">
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-150">
                        تسجيل الدفعة
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/payments/create.blade.php ENDPATH**/ ?>