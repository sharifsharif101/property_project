

<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
    <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <strong>حدثت بعض الأخطاء:</strong>
        <ul class="mt-2 list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="max-w-4xl mx-auto mt-10 bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-bold mb-6">إنشاء عقد جديد</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

<form action="<?php echo e(route('contracts.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
        <?php echo csrf_field(); ?>

        
        <div>
            <label>المستأجر</label>
            <select name="tenant_id" class="w-full border p-2 rounded">
                <option value="">اختر مستأجر</option>
                <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tenant->id); ?>"><?php echo e($tenant->first_name); ?> <?php echo e($tenant->last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div>
            <label>العقار</label>
            <select name="property_id" id="property-select" class="w-full border p-2 rounded">
                <option value="">اختر العقار</option>
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($property->property_id); ?>"><?php echo e($property->name ?? 'عقار #' . $property->property_id); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div>
            <label>الوحدة</label>
            <select name="unit_id" id="unit-select" class="w-full border p-2 rounded">
                <option value="">اختر وحدة</option>
            </select>
        </div>

        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label>تاريخ البداية</label>
                <input type="date" name="start_date" class="w-full border p-2 rounded">
            </div>
            <div>
                <label>تاريخ النهاية</label>
                <input type="date" name="end_date" class="w-full border p-2 rounded">
            </div>
        </div>

        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label>قيمة الإيجار</label>
                <input type="number" name="rent_amount" step="0.01" class="w-full border p-2 rounded">
            </div>
            <div>
                <label>نوع الإيجار</label>
                <select name="rent_type" class="w-full border p-2 rounded">
                    <option value="daily">يومي</option>
                    <option value="weekly">أسبوعي</option>
                    <option value="monthly" selected>شهري</option>
                    <option value="yearly">سنوي</option>
                </select>
            </div>
        </div>

        
        <div>
            <label>الضمان</label>
            <input type="number" name="security_deposit" step="0.01" class="w-full border p-2 rounded">
        </div>

        
        <div>
            <label>رقم المرجع</label>
            <input type="text" value="<?php echo e(old('reference_number', $referenceNumber ?? 'سيتم توليده تلقائيًا')); ?>" disabled
                class="w-full border p-2 rounded bg-gray-100 cursor-not-allowed" />
            <input type="hidden" name="reference_number" value="<?php echo e(old('reference_number', $referenceNumber ?? '')); ?>" />
        </div>

        
        <div>
            <label>الحالة</label>
            <select name="status" class="w-full border p-2 rounded">
                <option value="draft">مسودة</option>
                <option value="active">نشط</option>
                <option value="terminated">منتهي</option>
                <option value="cancelled">ملغي</option>
            </select>
        </div>


    
    <div>
        <label class="block mb-1 font-medium text-gray-700">ملف العقد (PDF)</label>
        <input type="file" name="contract_file" accept="application/pdf" required
               class="w-full border p-2 rounded file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
        <?php $__errorArgs = ['contract_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

        
        <div>
            <label>سبب الإنهاء</label>
            <select name="termination_reason" class="w-full border p-2 rounded">
                <option value="">-- إن وجد --</option>
                <option value="late_payment">تأخر في الدفع</option>
                <option value="property_damage">تلف في العقار</option>
                <option value="tenant_request">طلب المستأجر</option>
                <option value="landlord_request">طلب المالك</option>
                <option value="contract_expiry">انتهاء العقد</option>
                <option value="other">أخرى</option>
            </select>
        </div>

        
        <div>
            <label>ملاحظات الإنهاء</label>
            <textarea name="termination_notes" rows="3" class="w-full border p-2 rounded"></textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">حفظ العقد</button>
    </form>
</div>


 <script>
document.addEventListener('DOMContentLoaded', function () {
    const propertySelect = document.getElementById('property-select');
    const unitSelect = document.getElementById('unit-select');

    if (!propertySelect || !unitSelect) return;

    propertySelect.addEventListener('change', function () {
        const propertyId = this.value;
        unitSelect.innerHTML = '<option value="">جاري التحميل...</option>';

        if (!propertyId) {
            unitSelect.innerHTML = '<option value="">اختر وحدة</option>';
            return;
        }

        fetch(`/properties/${propertyId}/units`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Response not ok");
                }
                return response.json();
            })
            .then(units => {
                unitSelect.innerHTML = '';

                if (!Array.isArray(units) || units.length === 0) {
                    unitSelect.innerHTML = '<option value="">لا توجد وحدات متاحة</option>';
                    return;
                }

                unitSelect.innerHTML = '<option value="">اختر وحدة</option>';

                const disabledStatuses = ['rented', 'reserved', 'under_maintenance', 'disabled'];

                units.forEach(unit => {
                    const option = document.createElement('option');
                    option.value = unit.id;
                    option.textContent = `وحدة رقم ${unit.unit_number}`;

                    if (disabledStatuses.includes(unit.status)) {
                        option.disabled = true;
                        option.textContent += ' (غير متاحة)';
                    }

                    unitSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('خطأ أثناء تحميل الوحدات:', error);
                unitSelect.innerHTML = '<option value="">حدث خطأ في التحميل</option>';
            });
    });
});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/contracts/create.blade.php ENDPATH**/ ?>