



<?php $__env->startSection('title', 'لوحة التحكم الرئيسية'); ?>


<?php $__env->startSection('contents'); ?>
  <div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">سجل أقساط الإيجارات</h1>
        <a href="<?php echo e(route('payments.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="bi bi-plus-circle me-1"></i> إضافة دفعة جديدة
        </a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            
            

            <div class="table-responsive">
                
                <table id="installments-table" class="table table-hover align-middle" style="width:100%">
                    <thead class="table-light">
                        
                        <tr class="text-secondary">
                            <th>#</th>
                            <th>المستأجر</th>
                            <th>العقار / الوحدة</th>
                            <th>الرقم المرجعي للعقد</th>
                            <th>تاريخ الاستحقاق</th>
                            <th class="text-center">الحالة</th>
                            <th class="text-end">المبلغ المستحق</th>
                            <th class="text-end">المبلغ المدفوع</th>
                            <th class="text-end text-danger">المبلغ المتبقي</th>
                            <th class="text-center">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__empty_1 = true; $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($installment->id + 10000); ?></td>
                            <td>
                                <div><?php echo e($installment->contract->tenant->first_name ?? 'غير متوفر'); ?> <?php echo e($installment->contract->tenant->last_name ?? ''); ?></div>
                                <small class="text-muted" dir="ltr"><?php echo e($installment->contract->tenant->phone ?? ''); ?></small>
                            </td>
                            <td>
                                <div><?php echo e($installment->contract->property->name ?? 'غير متوفر'); ?></div>
                                <small class="text-muted">وحدة رقم: <?php echo e($installment->contract->unit->unit_number ?? 'N/A'); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?php echo e($installment->contract->reference_number ?? 'N/A'); ?></span>
                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($installment->due_date)->format('Y-m-d')); ?></td>
                            <td class="text-center">
                                <?php
                                    $statusConfig = [
                                        'Paid'           => ['class' => 'bg-success-subtle text-success-emphasis border border-success-subtle', 'text' => 'مدفوع بالكامل', 'icon' => 'bi-check-circle-fill'],
                                        'Partially Paid' => ['class' => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle', 'text' => 'مدفوع جزئياً', 'icon' => 'bi-pie-chart-fill'],
                                        'Overdue'        => ['class' => 'bg-danger-subtle text-danger-emphasis border border-danger-subtle', 'text' => 'متأخر', 'icon' => 'bi-exclamation-triangle-fill'],
                                        'Due'            => ['class' => 'bg-info-subtle text-info-emphasis border border-info-subtle', 'text' => 'مستحق', 'icon' => 'bi-hourglass-split'],
                                        'Cancelled'      => ['class' => 'bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle', 'text' => 'ملغي', 'icon' => 'bi-x-circle-fill'],
                                    ];
                                    $config = $statusConfig[$installment->status] ?? ['class' => 'bg-light', 'text' => $installment->status, 'icon' => 'bi-question-circle'];
                                ?>
                                <span class="badge rounded-pill <?php echo e($config['class']); ?>">
                                    <i class="bi <?php echo e($config['icon']); ?> me-1"></i><?php echo e($config['text']); ?>

                                </span>
                            </td>
                            <td class="text-end"><?php echo e(number_format($installment->amount_due + $installment->late_fee, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format($installment->amount_paid, 2)); ?></td>
                            <td class="text-end fw-bold text-danger">
                                <?php echo e(number_format(($installment->amount_due + $installment->late_fee) - $installment->amount_paid, 2)); ?>

                            </td>
                            <td class="text-center">
                                <?php if($installment->status == 'Paid'): ?>
                                    <span class="text-success" title="تم الدفع بالكامل"><i class="bi bi-check2-all fs-5"></i></span>
                                <?php elseif($installment->status == 'Cancelled'): ?>
                                    <span class="text-secondary" title="هذا القسط ملغي"><i class="bi bi-slash-circle fs-5"></i></span>
                                <?php else: ?>
                                    <a href="<?php echo e(route('payments.create', ['installment_id' => $installment->id])); ?>" 
                                       class="btn btn-sm <?php echo e($installment->status == 'Partially Paid' ? 'btn-warning' : 'btn-success'); ?>" 
                                       title="تسجيل دفعة لهذا القسط">
                                        <i class="bi bi-cash-coin"></i>
                                        <?php echo e($installment->status == 'Partially Paid' ? 'إكمال الدفع' : 'دفع الآن'); ?>

                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-5">
                                <i class="bi bi-journal-x fs-1"></i>
                                <h4 class="mt-3">لا توجد أقساط لعرضها حالياً.</h4>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
  <script>
    // alert('This script is specific to the dashboard page!');
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutss.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/dashboard/index.blade.php ENDPATH**/ ?>