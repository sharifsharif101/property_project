

<?php $__env->startSection('title', 'عرض العقارات'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div x-data="{ show: true }"
         x-init="setTimeout(() => show = false, 2000)"
         x-show="show"
         x-transition
         class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
         role="alert">
        <strong class="font-bold">نجاح!</strong>
        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 5000)" x-show="show" x-transition
            class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">خطأ!</strong>
            <ul class="mt-2 list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php echo e(Breadcrumbs::render('properties.create')); ?>

    <section class="content">


        <div
            class="w-4/5 mx-auto p-6 bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700">
            <div class="text-center my-6">
                <h1 class="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white">
                    إضافة عقار جديد
                </h1>
            </div>

            <div class="row">
                <div class="col-xs-12">


                    <div class="box-body">
                        <form action="<?php echo e(route('properties.store')); ?>" method="POST" class="w-4/5 mx-auto">
                            <?php echo csrf_field(); ?>

                            <!-- اسم العقار -->
                            <div>
                                <label for="name" class="block text-gray-700 font-medium mb-1">اسم العقار</label>
                                <input type="text" name="name" id="name"
                                    class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    value="<?php echo e(old('name')); ?>" required>

                            </div>

                            <!-- العنوان -->
                            <div>
                                <label for="address" class="block text-gray-700 font-medium mb-1">العنوان</label>
                                <input type="text" name="address" id="address"
                                    class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    value="<?php echo e(old('address')); ?>" required>

                            </div>

                            <!-- النوع -->
                            <div>
                                <label for="type" class="block text-gray-700 font-medium mb-1">نوع العقار</label>
                                <select name="type" id="type"
                                    class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required>
                                    <option value="">اختر النوع</option>
                                    <option value="big_house" <?php echo e(old('type') == 'big_house' ? 'selected' : ''); ?>>بيت كبير
                                    </option>
                                    <option value="building" <?php echo e(old('type') == 'building' ? 'selected' : ''); ?>>عمارة
                                    </option>
                                    <option value="villa" <?php echo e(old('type') == 'villa' ? 'selected' : ''); ?>>فلة</option>
                                </select>

                            </div>

                            <!-- الحالة -->
                            <div>
                                <label for="status" class="block text-gray-700 font-medium mb-1">الحالة</label>
                                <select name="status" id="status"
                                    class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required>
                                    <option value="">اختر الحالة</option>
                                    <option value="available" <?php echo e(old('status') == 'available' ? 'selected' : ''); ?>>متاح
                                    </option>
                                    <option value="rented" <?php echo e(old('status') == 'rented' ? 'selected' : ''); ?>>مؤجر</option>
                                    <option value="under_maintenance"
                                        <?php echo e(old('status') == 'under_maintenance' ? 'selected' : ''); ?>>تحت
                                        الصيانة</option>
                                </select>
                            </div>

                            <!-- زر الحفظ -->
                            <div class="text-center pt-4">


                                <button type="submit"
                                    class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                                    style="color: white !important;">حفظ العقار</button>

                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/properties/create.blade.php ENDPATH**/ ?>