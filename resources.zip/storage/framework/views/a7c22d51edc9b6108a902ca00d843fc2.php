<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
  <title><?php echo $__env->yieldContent('title', 'لوحة التحكم'); ?></title>
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Cairo', sans-serif; }
    .submenu { max-height: 0; transition: max-height 0.3s ease-out; }
  </style>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gray-100 flex min-h-screen">

  <!-- Overlay for mobile menu -->
  <div id="overlay" class="fixed inset-0 bg-black/40 z-40 hidden lg:hidden"></div>

  
  <?php echo $__env->make('layoutss.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Main Content Wrapper -->
  <div class="flex-grow flex flex-col">

    
    <?php echo $__env->make('layoutss.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Page Content -->
    <main class="p-8">
      
      <?php echo $__env->yieldContent('contents'); ?>
    </main>
    
  </div>

  
  <script>
    const sidebar = document.getElementById("sidebar");
    const menuBtn = document.getElementById("menuBtn");
    const overlay = document.getElementById("overlay");

    function toggleMenu() {
      sidebar.classList.toggle("translate-x-full");
      overlay.classList.toggle("hidden");
    }

    menuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    overlay.addEventListener("click", () => {
      toggleMenu();
    });

    const dropdownToggles = document.querySelectorAll(".dropdown-toggle");
    dropdownToggles.forEach(toggle => {
      toggle.addEventListener("click", () => {
        const submenu = toggle.nextElementSibling;
        const chevron = toggle.querySelector(".chevron");
        if (submenu.style.maxHeight && submenu.style.maxHeight !== '0px') {
          submenu.style.maxHeight = '0px';
          chevron.classList.remove("rotate-180");
        } else {
          submenu.style.maxHeight = submenu.scrollHeight + "px";
          chevron.classList.add("rotate-180");
        }
      });
    });
  </script>
  
  
  <?php echo $__env->yieldPushContent('scriptss'); ?>

</body>
</html><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/layoutss/app.blade.php ENDPATH**/ ?>