

<?php $__env->startSection('title', 'سجل المدفوعات'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(session('success')): ?>
        <div class="mb-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded-md shadow-sm" role="alert">
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-4 p-4 bg-red-100 border-l-4 border-red-500 text-red-700 rounded-md shadow-sm" role="alert">
            <p><?php echo e(session('error')); ?></p>
        </div>
    <?php endif; ?>
 
    <!-- الكارد الرئيسي -->
    <div class="bg-white rounded-lg shadow-md">
        <!-- رأس الكارد -->
  <div class="p-6 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
    
    
    <h2 class="text-xl font-bold text-gray-800">سجل المدفوعات</h2>
    
    
    <div class="flex items-center gap-3">
        
        
        <a href="<?php echo e(route('payments.accordion')); ?>" 
           class="inline-flex items-center gap-2 bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-gray-700 transition-colors">
            <i class="bi bi-collection"></i>
            <span>عرض مجمع</span>
        </a>

        
        <a href="<?php echo e(route('payments.create')); ?>" 
           class="inline-flex items-center gap-2 bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-blue-700 transition-colors">
            <i class="bi bi-plus-circle"></i>
            <span>إضافة دفعة جديدة</span>
        </a>

    </div>

</div>
        <!-- محتوى الكارد -->
        <div class="p-6">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-right">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="p-3 font-medium">#</th>
                            <th class="p-3 font-medium">المستأجر</th>
                            <th class="p-3 font-medium">مرجع القسط</th>
                            <th class="p-3 font-medium">تاريخ الدفع</th>
                            <th class="p-3 font-medium text-left">المبلغ</th>
                            <th class="p-3 font-medium">طريقة الدفع</th>
                            <th class="p-3 font-medium text-center">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="p-3 text-gray-700 font-mono"><?php echo e($payment->id); ?></td>
                            <td class="p-3 whitespace-nowrap">
                                
                                <div class="font-semibold text-gray-900"><?php echo e($payment->contract->tenant->first_name ?? ''); ?> <?php echo e($payment->contract->tenant->last_name ?? 'N/A'); ?></div>
                                <div class="text-gray-500" dir="ltr"><?php echo e($payment->contract->tenant->phone ?? ''); ?></div>
                            </td>
                            <td class="p-3">
                                <a href="<?php echo e(route('installments.index', ['installment_id' => $payment->rent_installment_id])); ?>" class="text-blue-600 hover:underline">
                                    قسط #<?php echo e($payment->rent_installment_id + 10000); ?>

                                </a>
                            </td>
                            <td class="p-3 text-gray-800" dir="ltr"><?php echo e($payment->payment_date->format('Y-m-d')); ?></td>
                            <td class="p-3 text-left font-mono text-green-700 font-semibold"><?php echo e(number_format($payment->amount, 2)); ?></td>
                            <td class="p-3 text-gray-600"><?php echo e($payment->payment_method); ?></td>
                            
                            
                            <td class="p-3 text-center">
                                <form action="<?php echo e(route('payments.destroy', $payment->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('هل أنت متأكد من رغبتك في إلغاء هذه الدفعة؟ سيتم خصم المبلغ من القسط المرتبط.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="inline-flex items-center gap-x-2 bg-red-500 text-white font-semibold py-1.5 px-3 rounded-md shadow-sm hover:bg-red-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                            title="إلغاء الدفعة">
                                        <i class="bi bi-arrow-counterclockwise"></i>
                                        <span>إلغاء</span>
                                    </button>
                                </form>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-16 text-gray-500">
                                <div class="flex flex-col items-center">
                                    <i class="bi bi-wallet2 text-5xl text-gray-300"></i>
                                    <h4 class="mt-4 font-semibold text-lg">لا توجد أي مدفوعات مسجلة بعد.</h4>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- روابط التنقل بين الصفحات -->
            <div class="mt-6">
                <?php echo e($payments->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sharif\Desktop\property_project\property_project\resources\views/payments/index.blade.php ENDPATH**/ ?>